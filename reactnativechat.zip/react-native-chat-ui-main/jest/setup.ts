jest.mock('react-native/Libraries/Animated/NativeAnimatedHelper')
jest.spyOn(Date, 'now').mockReturnValue(0)
