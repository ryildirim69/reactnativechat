module.exports = {
  jsxSingleQuote: true,
  semi: false,
  singleQuote: true,
}
