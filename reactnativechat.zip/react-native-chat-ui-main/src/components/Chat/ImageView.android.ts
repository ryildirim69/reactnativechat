import ImageView from 'react-native-image-viewing'

export default ImageView
