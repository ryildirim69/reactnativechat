package com.example

import com.facebook.react.ReactActivity

class MainActivity : ReactActivity() {

    override fun getMainComponentName(): String? {
        return "example"
    }
}
